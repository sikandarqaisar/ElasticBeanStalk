<?php

/**
  * Configuration for database connection
  *
  */

$host       = "localhost";
$username   = "alam";
$password   = "03325181228";
$dbname     = "crud"; // will use later
$dsn        = "mysql:host=$host;dbname=$dbname"; // will use later
$options    = array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
              );

?>
